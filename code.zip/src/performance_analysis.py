"""
Performance Analysis and Visualization Tool
CST435 Assignment 2
"""

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import json
import time
import os
from multiprocessing_image_processor import MultiprocessingImageProcessor
from concurrent_futures_image_processor import ConcurrentFuturesImageProcessor


class PerformanceAnalyzer:
    """Analyze and visualize performance of parallel implementations"""
    
    def __init__(self, image_dir, num_runs=3):
        """
        Initialize analyzer
        Args:
            image_dir: Directory containing test images
            num_runs: Number of runs to average results
        """
        self.image_dir = image_dir
        self.num_runs = num_runs
        self.results = {
            'multiprocessing': {},
            'concurrent_futures': {}
        }
    
    def run_benchmarks(self, worker_counts=[1, 2, 4, 8]):
        """
        Run benchmarks for both implementations
        
        Args:
            worker_counts: List of worker/process counts to test
        """
        print("="*70)
        print("STARTING COMPREHENSIVE PERFORMANCE BENCHMARKS")
        print("="*70)
        
        # Test Multiprocessing
        print("\n" + "="*70)
        print("Testing Multiprocessing Implementation")
        print("="*70)
        
        for num_proc in worker_counts:
            print(f"\n--- Testing with {num_proc} process(es) ---")
            times = []
            
            for run in range(self.num_runs):
                print(f"Run {run + 1}/{self.num_runs}...", end=" ")
                processor = MultiprocessingImageProcessor(num_processes=num_proc)
                exec_time = processor.process_images(
                    self.image_dir, 
                    f"output_mp_{num_proc}"
                )
                times.append(exec_time)
                print(f"{exec_time:.2f}s")
            
            avg_time = np.mean(times)
            std_time = np.std(times)
            self.results['multiprocessing'][num_proc] = {
                'times': times,
                'avg': avg_time,
                'std': std_time
            }
            print(f"Average: {avg_time:.2f}s (±{std_time:.2f}s)")
        
        # Test Concurrent.futures
        print("\n" + "="*70)
        print("Testing Concurrent.futures Implementation")
        print("="*70)
        
        for num_workers in worker_counts:
            print(f"\n--- Testing with {num_workers} worker(s) ---")
            times = []
            
            for run in range(self.num_runs):
                print(f"Run {run + 1}/{self.num_runs}...", end=" ")
                processor = ConcurrentFuturesImageProcessor(
                    num_workers=num_workers,
                    use_processes=True
                )
                exec_time = processor.process_images(
                    self.image_dir, 
                    f"output_cf_{num_workers}"
                )
                times.append(exec_time)
                print(f"{exec_time:.2f}s")
            
            avg_time = np.mean(times)
            std_time = np.std(times)
            self.results['concurrent_futures'][num_workers] = {
                'times': times,
                'avg': avg_time,
                'std': std_time
            }
            print(f"Average: {avg_time:.2f}s (±{std_time:.2f}s)")
    
    def calculate_metrics(self):
        """Calculate speedup and efficiency metrics"""
        metrics = {
            'multiprocessing': {},
            'concurrent_futures': {}
        }
        
        for paradigm in ['multiprocessing', 'concurrent_futures']:
            baseline = self.results[paradigm][1]['avg']
            
            for workers, data in self.results[paradigm].items():
                speedup = baseline / data['avg']
                efficiency = (speedup / workers) * 100
                
                metrics[paradigm][workers] = {
                    'time': data['avg'],
                    'std': data['std'],
                    'speedup': speedup,
                    'efficiency': efficiency
                }
        
        return metrics
    
    def print_summary_table(self, metrics):
        """Print formatted summary table"""
        print("\n" + "="*90)
        print("PERFORMANCE SUMMARY - MULTIPROCESSING")
        print("="*90)
        print(f"{'Processes':<12} {'Time (s)':<15} {'Speedup':<12} {'Efficiency':<12}")
        print("-"*90)
        
        for workers in sorted(metrics['multiprocessing'].keys()):
            m = metrics['multiprocessing'][workers]
            print(f"{workers:<12} {m['time']:<15.2f} {m['speedup']:<12.2f}x {m['efficiency']:<12.1f}%")
        
        print("\n" + "="*90)
        print("PERFORMANCE SUMMARY - CONCURRENT.FUTURES")
        print("="*90)
        print(f"{'Workers':<12} {'Time (s)':<15} {'Speedup':<12} {'Efficiency':<12}")
        print("-"*90)
        
        for workers in sorted(metrics['concurrent_futures'].keys()):
            m = metrics['concurrent_futures'][workers]
            print(f"{workers:<12} {m['time']:<15.2f} {m['speedup']:<12.2f}x {m['efficiency']:<12.1f}%")
    
    def create_visualizations(self, metrics, output_dir='visualizations'):
        """Create performance visualization charts"""
        os.makedirs(output_dir, exist_ok=True)
        
        workers = sorted(metrics['multiprocessing'].keys())
        
        # Extract data
        mp_times = [metrics['multiprocessing'][w]['time'] for w in workers]
        cf_times = [metrics['concurrent_futures'][w]['time'] for w in workers]
        mp_speedup = [metrics['multiprocessing'][w]['speedup'] for w in workers]
        cf_speedup = [metrics['concurrent_futures'][w]['speedup'] for w in workers]
        mp_efficiency = [metrics['multiprocessing'][w]['efficiency'] for w in workers]
        cf_efficiency = [metrics['concurrent_futures'][w]['efficiency'] for w in workers]
        
        # Create figure with subplots
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Parallel Image Processing Performance Analysis', fontsize=16, fontweight='bold')
        
        # 1. Execution Time Comparison
        ax = axes[0, 0]
        x = np.arange(len(workers))
        width = 0.35
        
        ax.bar(x - width/2, mp_times, width, label='Multiprocessing', color='steelblue')
        ax.bar(x + width/2, cf_times, width, label='Concurrent.futures', color='darkorange')
        
        ax.set_xlabel('Number of Workers/Processes', fontweight='bold')
        ax.set_ylabel('Execution Time (seconds)', fontweight='bold')
        ax.set_title('Execution Time Comparison')
        ax.set_xticks(x)
        ax.set_xticklabels(workers)
        ax.legend()
        ax.grid(axis='y', alpha=0.3)
        
        # 2. Speedup Comparison
        ax = axes[0, 1]
        ax.plot(workers, mp_speedup, marker='o', linewidth=2, markersize=8, 
                label='Multiprocessing', color='steelblue')
        ax.plot(workers, cf_speedup, marker='s', linewidth=2, markersize=8, 
                label='Concurrent.futures', color='darkorange')
        ax.plot(workers, workers, linestyle='--', color='gray', 
                label='Ideal (Linear)', alpha=0.7)
        
        ax.set_xlabel('Number of Workers/Processes', fontweight='bold')
        ax.set_ylabel('Speedup', fontweight='bold')
        ax.set_title('Speedup Analysis')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 3. Efficiency Comparison
        ax = axes[1, 0]
        ax.plot(workers, mp_efficiency, marker='o', linewidth=2, markersize=8, 
                label='Multiprocessing', color='steelblue')
        ax.plot(workers, cf_efficiency, marker='s', linewidth=2, markersize=8, 
                label='Concurrent.futures', color='darkorange')
        ax.axhline(y=100, linestyle='--', color='gray', label='100% Efficiency', alpha=0.7)
        
        ax.set_xlabel('Number of Workers/Processes', fontweight='bold')
        ax.set_ylabel('Efficiency (%)', fontweight='bold')
        ax.set_title('Parallel Efficiency')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim([0, 110])
        
        # 4. Performance Comparison Table
        ax = axes[1, 1]
        ax.axis('tight')
        ax.axis('off')
        
        table_data = []
        table_data.append(['Workers', 'MP Time', 'CF Time', 'MP Speedup', 'CF Speedup'])
        
        for i, w in enumerate(workers):
            table_data.append([
                str(w),
                f"{mp_times[i]:.2f}s",
                f"{cf_times[i]:.2f}s",
                f"{mp_speedup[i]:.2f}x",
                f"{cf_speedup[i]:.2f}x"
            ])
        
        table = ax.table(cellText=table_data, cellLoc='center', loc='center',
                        colWidths=[0.15, 0.2, 0.2, 0.2, 0.2])
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1, 2)
        
        # Style header row
        for i in range(5):
            table[(0, i)].set_facecolor('#4472C4')
            table[(0, i)].set_text_props(weight='bold', color='white')
        
        plt.tight_layout()
        
        # Save figure
        output_path = os.path.join(output_dir, 'performance_analysis.png')
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"\nVisualization saved to: {output_path}")
        
        plt.show()
    
    def save_results(self, metrics, filename='performance_results.json'):
        """Save results to JSON file"""
        output_data = {
            'raw_results': self.results,
            'metrics': metrics,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        
        with open(filename, 'w') as f:
            json.dump(output_data, f, indent=4)
        
        print(f"\nResults saved to: {filename}")
    
    def export_to_csv(self, metrics, filename='performance_metrics.csv'):
        """Export metrics to CSV for easy reporting"""
        data = []
        
        for paradigm in ['multiprocessing', 'concurrent_futures']:
            for workers, m in metrics[paradigm].items():
                data.append({
                    'Paradigm': paradigm.replace('_', '.'),
                    'Workers': workers,
                    'Time (s)': m['time'],
                    'Std Dev': m['std'],
                    'Speedup': m['speedup'],
                    'Efficiency (%)': m['efficiency']
                })
        
        df = pd.DataFrame(data)
        df.to_csv(filename, index=False)
        print(f"Metrics exported to: {filename}")


def main():
    """Main execution function"""
    # Configuration
    IMAGE_DIR = "input_images"  # Change to your image directory
    NUM_RUNS = 3  # Number of runs to average
    WORKER_COUNTS = [1, 2, 4, 8]  # Worker counts to test
    
    # Create analyzer
    analyzer = PerformanceAnalyzer(IMAGE_DIR, num_runs=NUM_RUNS)
    
    # Run benchmarks
    analyzer.run_benchmarks(worker_counts=WORKER_COUNTS)
    
    # Calculate metrics
    metrics = analyzer.calculate_metrics()
    
    # Print summary
    analyzer.print_summary_table(metrics)
    
    # Create visualizations
    analyzer.create_visualizations(metrics)
    
    # Save results
    analyzer.save_results(metrics)
    analyzer.export_to_csv(metrics)
    
    print("\n" + "="*70)
    print("PERFORMANCE ANALYSIS COMPLETE")
    print("="*70)


if __name__ == "__main__":
    main()