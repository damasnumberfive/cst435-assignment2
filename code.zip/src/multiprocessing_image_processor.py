"""
Image Processing System using Python Multiprocessing
WITH PROGRESS TRACKING - You can see what's happening!
"""

import numpy as np
from PIL import Image
import multiprocessing as mp
from multiprocessing import Pool
import time
import os
from pathlib import Path

class ImageFilters:
    """Collection of image processing filters"""
    
    @staticmethod
    def grayscale(image_array):
        """Convert RGB to grayscale using luminance formula"""
        if len(image_array.shape) == 3:
            return np.dot(image_array[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)
        return image_array
    
    @staticmethod
    def gaussian_blur(image_array):
        """Apply 3x3 Gaussian blur"""
        kernel = np.array([[1, 2, 1],
                          [2, 4, 2],
                          [1, 2, 1]]) / 16.0
        return ImageFilters._apply_kernel(image_array, kernel)
    
    @staticmethod
    def edge_detection(image_array):
        """Sobel edge detection"""
        if len(image_array.shape) == 3:
            gray = ImageFilters.grayscale(image_array)
        else:
            gray = image_array
        
        sobel_x = np.array([[-1, 0, 1],
                           [-2, 0, 2],
                           [-1, 0, 1]])
        
        sobel_y = np.array([[-1, -2, -1],
                           [0, 0, 0],
                           [1, 2, 1]])
        
        edge_x = ImageFilters._apply_kernel(gray, sobel_x)
        edge_y = ImageFilters._apply_kernel(gray, sobel_y)
        
        edges = np.sqrt(edge_x**2 + edge_y**2)
        edges = np.clip(edges, 0, 255).astype(np.uint8)
        
        return edges
    
    @staticmethod
    def sharpen(image_array):
        """Sharpen image to enhance edges"""
        kernel = np.array([[0, -1, 0],
                          [-1, 5, -1],
                          [0, -1, 0]])
        return ImageFilters._apply_kernel(image_array, kernel)
    
    @staticmethod
    def brightness_adjustment(image_array, factor=1.3):
        """Adjust brightness"""
        adjusted = image_array.astype(np.float32) * factor
        adjusted = np.clip(adjusted, 0, 255).astype(np.uint8)
        return adjusted
    
    @staticmethod
    def _apply_kernel(image_array, kernel):
        """Apply convolution kernel to image"""
        if len(image_array.shape) == 3:
            result = np.zeros_like(image_array)
            for c in range(image_array.shape[2]):
                result[:, :, c] = ImageFilters._convolve2d(image_array[:, :, c], kernel)
            return result
        else:
            return ImageFilters._convolve2d(image_array, kernel)
    
    @staticmethod
    def _convolve2d(image, kernel):
        """2D convolution operation"""
        h, w = image.shape
        kh, kw = kernel.shape
        pad_h, pad_w = kh // 2, kw // 2
        
        padded = np.pad(image, ((pad_h, pad_h), (pad_w, pad_w)), mode='edge')
        result = np.zeros_like(image, dtype=np.float32)
        
        for i in range(h):
            for j in range(w):
                region = padded[i:i+kh, j:j+kw]
                result[i, j] = np.sum(region * kernel)
        
        return np.clip(result, 0, 255).astype(np.uint8)


# Global counter for progress tracking
completed_tasks = None

def init_worker(counter):
    """Initialize worker process with shared counter"""
    global completed_tasks
    completed_tasks = counter


def process_single_image(args):
    """Process a single image with filter - WITH PROGRESS"""
    global completed_tasks
    image_path, output_dir, filter_name, task_num, total_tasks = args
    
    try:
        # Load image
        img = Image.open(image_path)
        img_array = np.array(img)
        
        # Apply filter
        filters = {
            'grayscale': ImageFilters.grayscale,
            'blur': ImageFilters.gaussian_blur,
            'edge': ImageFilters.edge_detection,
            'sharpen': ImageFilters.sharpen,
            'brightness': ImageFilters.brightness_adjustment
        }
        
        processed = filters[filter_name](img_array)
        
        # Save result
        output_path = os.path.join(output_dir, filter_name, os.path.basename(image_path))
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        Image.fromarray(processed).save(output_path)
        
        # Update progress
        if completed_tasks is not None:
            with completed_tasks.get_lock():
                completed_tasks.value += 1
                current = completed_tasks.value
                # Print progress every 10 tasks
                if current % 10 == 0 or current == total_tasks:
                    percent = (current / total_tasks) * 100
                    print(f"  Progress: {current}/{total_tasks} tasks ({percent:.1f}%) - Just completed: {os.path.basename(image_path)} [{filter_name}]")
        
        return True
    except Exception as e:
        print(f"  ❌ Error processing {image_path} with {filter_name}: {e}")
        return False


class MultiprocessingImageProcessor:
    """Image processor using Python multiprocessing"""
    
    def __init__(self, num_processes=None):
        self.num_processes = num_processes or mp.cpu_count()
    
    def process_images(self, image_dir, output_dir):
        """Process all images with progress tracking"""
        # Get all image files
        image_extensions = ('.jpg', '.jpeg', '.png', '.bmp')
        image_files = [
            os.path.join(image_dir, f) 
            for f in os.listdir(image_dir) 
            if f.lower().endswith(image_extensions)
        ]
        
        print(f"Found {len(image_files)} images")
        print(f"Using {self.num_processes} processes")
        
        # Create task list
        tasks = []
        filters = ['grayscale', 'blur', 'edge', 'sharpen', 'brightness']
        
        for img_path in image_files:
            for filter_name in filters:
                tasks.append((img_path, output_dir, filter_name, len(tasks), len(image_files) * len(filters)))
        
        total_tasks = len(tasks)
        print(f"Total tasks: {total_tasks}")
        print("Starting processing...")
        print("")
        
        # Create shared counter for progress
        counter = mp.Value('i', 0)
        
        # Process with multiprocessing
        start_time = time.time()
        
        with Pool(processes=self.num_processes, initializer=init_worker, initargs=(counter,)) as pool:
            results = pool.map(process_single_image, tasks)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        successful = sum(results)
        print(f"\n✅ Processed {successful}/{len(tasks)} tasks successfully")
        print(f"⏱️  Execution time: {execution_time:.2f} seconds")
        
        return execution_time


def main():
    """Main execution function"""
    # Configuration
    IMAGE_DIR = "input_images"
    OUTPUT_DIR = "output_multiprocessing"
    
    # Test with different process counts
    process_counts = [1, 2, 4]  # Reduced for faster testing
    results = {}
    
    print("="*60)
    print("Multiprocessing Image Processing Performance Test")
    print("WITH PROGRESS TRACKING")
    print("="*60)
    print("")
    
    for num_proc in process_counts:
        print(f"\n{'='*60}")
        print(f"Testing with {num_proc} process(es)")
        print('='*60)
        
        processor = MultiprocessingImageProcessor(num_processes=num_proc)
        exec_time = processor.process_images(IMAGE_DIR, OUTPUT_DIR)
        
        results[num_proc] = exec_time
        
        # Calculate speedup
        if num_proc == 1:
            baseline = exec_time
        else:
            speedup = baseline / exec_time
            efficiency = (speedup / num_proc) * 100
            print(f"📊 Speedup: {speedup:.2f}x")
            print(f"📊 Efficiency: {efficiency:.1f}%")
    
    # Print summary
    print("\n" + "="*60)
    print("PERFORMANCE SUMMARY")
    print("="*60)
    print(f"{'Processes':<12} {'Time (s)':<12} {'Speedup':<12} {'Efficiency'}")
    print("-"*60)
    
    for num_proc in process_counts:
        exec_time = results[num_proc]
        if num_proc == 1:
            print(f"{num_proc:<12} {exec_time:<12.2f} {'1.00x':<12} {'100.0%'}")
        else:
            speedup = results[1] / exec_time
            efficiency = (speedup / num_proc) * 100
            print(f"{num_proc:<12} {exec_time:<12.2f} {speedup:<12.2f}x {efficiency:.1f}%")


if __name__ == "__main__":
    main()