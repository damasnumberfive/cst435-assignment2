"""
Image Processing System using Python concurrent.futures
CST435 Assignment 2 - Parallel Implementation
"""

import numpy as np
from PIL import Image
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import time
import os

class ImageFilters:
    """Collection of image processing filters"""
    
    @staticmethod
    def grayscale(image_array):
        """Convert RGB to grayscale using luminance formula"""
        if len(image_array.shape) == 3:
            return np.dot(image_array[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)
        return image_array
    
    @staticmethod
    def gaussian_blur(image_array):
        """Apply 3x3 Gaussian blur"""
        kernel = np.array([[1, 2, 1],
                          [2, 4, 2],
                          [1, 2, 1]]) / 16.0
        return ImageFilters._apply_kernel(image_array, kernel)
    
    @staticmethod
    def edge_detection(image_array):
        """Sobel edge detection"""
        if len(image_array.shape) == 3:
            gray = ImageFilters.grayscale(image_array)
        else:
            gray = image_array
        
        sobel_x = np.array([[-1, 0, 1],
                           [-2, 0, 2],
                           [-1, 0, 1]])
        
        sobel_y = np.array([[-1, -2, -1],
                           [0, 0, 0],
                           [1, 2, 1]])
        
        edge_x = ImageFilters._apply_kernel(gray, sobel_x)
        edge_y = ImageFilters._apply_kernel(gray, sobel_y)
        
        edges = np.sqrt(edge_x**2 + edge_y**2)
        edges = np.clip(edges, 0, 255).astype(np.uint8)
        
        return edges
    
    @staticmethod
    def sharpen(image_array):
        """Sharpen image to enhance edges"""
        kernel = np.array([[0, -1, 0],
                          [-1, 5, -1],
                          [0, -1, 0]])
        return ImageFilters._apply_kernel(image_array, kernel)
    
    @staticmethod
    def brightness_adjustment(image_array, factor=1.3):
        """Adjust brightness"""
        adjusted = image_array.astype(np.float32) * factor
        adjusted = np.clip(adjusted, 0, 255).astype(np.uint8)
        return adjusted
    
    @staticmethod
    def _apply_kernel(image_array, kernel):
        """Apply convolution kernel to image"""
        if len(image_array.shape) == 3:
            result = np.zeros_like(image_array)
            for c in range(image_array.shape[2]):
                result[:, :, c] = ImageFilters._convolve2d(image_array[:, :, c], kernel)
            return result
        else:
            return ImageFilters._convolve2d(image_array, kernel)
    
    @staticmethod
    def _convolve2d(image, kernel):
        """2D convolution operation"""
        h, w = image.shape
        kh, kw = kernel.shape
        pad_h, pad_w = kh // 2, kw // 2
        
        padded = np.pad(image, ((pad_h, pad_h), (pad_w, pad_w)), mode='edge')
        result = np.zeros_like(image, dtype=np.float32)
        
        for i in range(h):
            for j in range(w):
                region = padded[i:i+kh, j:j+kw]
                result[i, j] = np.sum(region * kernel)
        
        return np.clip(result, 0, 255).astype(np.uint8)


def process_single_image_cf(args):
    """Process a single image with all filters - for concurrent.futures"""
    image_path, output_dir, filter_name = args
    
    try:
        # Load image
        img = Image.open(image_path)
        img_array = np.array(img)
        
        # Apply filter
        filters = {
            'grayscale': ImageFilters.grayscale,
            'blur': ImageFilters.gaussian_blur,
            'edge': ImageFilters.edge_detection,
            'sharpen': ImageFilters.sharpen,
            'brightness': ImageFilters.brightness_adjustment
        }
        
        processed = filters[filter_name](img_array)
        
        # Save result
        output_path = os.path.join(output_dir, filter_name, os.path.basename(image_path))
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        Image.fromarray(processed).save(output_path)
        
        return True
    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return False


class ConcurrentFuturesImageProcessor:
    """Image processor using concurrent.futures"""
    
    def __init__(self, num_workers=None, use_processes=True):
        """
        Initialize processor
        Args:
            num_workers: Number of workers to use
            use_processes: Use ProcessPoolExecutor (True) or ThreadPoolExecutor (False)
        """
        self.num_workers = num_workers or os.cpu_count()
        self.use_processes = use_processes
    
    def process_images(self, image_dir, output_dir):
        """
        Process all images in directory with all filters
        
        Args:
            image_dir: Directory containing input images
            output_dir: Directory for output images
        
        Returns:
            execution_time: Time taken to process all images
        """
        # Get all image files
        image_extensions = ('.jpg', '.jpeg', '.png', '.bmp')
        image_files = [
            os.path.join(image_dir, f) 
            for f in os.listdir(image_dir) 
            if f.lower().endswith(image_extensions)
        ]
        
        print(f"Found {len(image_files)} images")
        executor_type = "ProcessPoolExecutor" if self.use_processes else "ThreadPoolExecutor"
        print(f"Using {executor_type} with {self.num_workers} workers")
        
        # Create task list
        tasks = []
        filters = ['grayscale', 'blur', 'edge', 'sharpen', 'brightness']
        
        for img_path in image_files:
            for filter_name in filters:
                tasks.append((img_path, output_dir, filter_name))
        
        print(f"Total tasks: {len(tasks)}")
        
        # Process with concurrent.futures
        start_time = time.time()
        
        # Choose executor type
        ExecutorClass = ProcessPoolExecutor if self.use_processes else ThreadPoolExecutor
        
        with ExecutorClass(max_workers=self.num_workers) as executor:
            # Submit all tasks
            futures = [executor.submit(process_single_image_cf, task) for task in tasks]
            
            # Wait for completion
            results = [future.result() for future in futures]
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        successful = sum(results)
        print(f"\nProcessed {successful}/{len(tasks)} tasks successfully")
        print(f"Execution time: {execution_time:.2f} seconds")
        
        return execution_time


def main():
    """Main execution function"""
    # Configuration
    IMAGE_DIR = "input_images"  # Change to your image directory
    OUTPUT_DIR = "output_concurrent_futures"
    
    # Test with different worker counts (using ProcessPoolExecutor)
    worker_counts = [1, 2, 4, 8]
    results = {}
    
    print("="*60)
    print("Concurrent.futures Image Processing Performance Test")
    print("="*60)
    
    for num_workers in worker_counts:
        print(f"\n--- Testing with {num_workers} worker(s) ---")
        
        processor = ConcurrentFuturesImageProcessor(
            num_workers=num_workers, 
            use_processes=True  # Change to False for ThreadPoolExecutor
        )
        exec_time = processor.process_images(IMAGE_DIR, OUTPUT_DIR)
        
        results[num_workers] = exec_time
        
        # Calculate speedup
        if num_workers == 1:
            baseline = exec_time
        else:
            speedup = baseline / exec_time
            efficiency = (speedup / num_workers) * 100
            print(f"Speedup: {speedup:.2f}x")
            print(f"Efficiency: {efficiency:.1f}%")
    
    # Print summary
    print("\n" + "="*60)
    print("PERFORMANCE SUMMARY")
    print("="*60)
    print(f"{'Workers':<12} {'Time (s)':<12} {'Speedup':<12} {'Efficiency'}")
    print("-"*60)
    
    for num_workers in worker_counts:
        exec_time = results[num_workers]
        if num_workers == 1:
            print(f"{num_workers:<12} {exec_time:<12.2f} {'1.00x':<12} {'100.0%'}")
        else:
            speedup = results[1] / exec_time
            efficiency = (speedup / num_workers) * 100
            print(f"{num_workers:<12} {exec_time:<12.2f} {speedup:<12.2f}x {efficiency:.1f}%")


if __name__ == "__main__":
    main()